package com.example.proofofconceptserver;
import org.springframework.web.bind.annotation.*;

import java.util.TreeMap;

@RestController
public class TestController
{
    private TreeMap<String, Test> friends = new TreeMap<String, Test>();
    private static final String dummy = new Test( "", "" ).toJson();

    @GetMapping("/friend/{phoneNo}")
    public synchronized String getFriend( @PathVariable(value = "phoneNo") String phoneNo )
    {
        Test f = friends.get( phoneNo );

        if( f == null )
            return dummy;
        else
            return f.toJson();
    }

    @RequestMapping("/friend/{phoneNo}")
    public synchronized void putFriend(@RequestBody String json, @PathVariable String phoneNo )
    {
        Test f = Test.fromJson( json );
        friends.put( f.getPhoneNo(), f );
    }
}
