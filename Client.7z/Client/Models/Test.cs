﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Client.Models
{
    public class Test
    {
        public string phoneNo { get; set; }
        public string name { get; set; }    
    }
}